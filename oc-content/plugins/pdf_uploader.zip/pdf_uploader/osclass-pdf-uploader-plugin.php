<?php
/*
Plugin Name: PDF Uploader for Item Post
Plugin URI: https://example.com/
Description: Adds a PDF upload field to the item add/edit form and attaches the uploaded PDF to the item (link added to description).
Version: 1.0
Author: ChatGPT
Author URI: https://openai.com
*/

// Prevent direct access
if (!defined('OC_ADMIN')) define('OC_ADMIN', false);
if (!defined('OC_WEB'))   define('OC_WEB', true);

// Hook to show field on the item add/edit form (many themes support item_form hooks or variants)
osc_add_hook('item_form', 'pdf_uploader_show_field');
osc_add_hook('item_edit', 'pdf_uploader_show_field');

// Hook before item is posted - we will handle the uploaded file here
osc_add_hook('pre_item_post', 'pdf_uploader_handle_upload', 10);

// Plugin install/uninstall hooks
function pdf_uploader_install() {
    // create folder inside current theme: oc-content/themes/<theme>/images/pdf
    $dir = osc_content_path() . 'themes/' . osc_current_web_theme() . '/images/pdf/';
    if (!is_dir($dir)) {
        @mkdir($dir, 0755, true);
    }
}

function pdf_uploader_uninstall() {
    // nothing destructive on uninstall (we don't delete uploaded files automatically)
}

osc_register_plugin(osc_plugin_path(__FILE__), 'pdf_uploader_install');
osc_unregister_plugin(osc_plugin_path(__FILE__), 'pdf_uploader_uninstall');


// Show the PDF upload field in the item add/edit page
function pdf_uploader_show_field() {
    // try to show existing file when editing
    $existing_link = '';
    if (function_exists('osc_item_id') && osc_item_id() > 0) {
        // try to find a PDF link inside description (we stored it there)
        $desc = osc_item_description();
        if (preg_match('#<a[^>]+href=["\']([^"\']+\.pdf)["\']#i', $desc, $m)) {
            $url = $m[1];
            $existing_link = '<div class="pdf-uploader-existing">ملف PDF موجود: <a href="' . $url . '" target="_blank">فتح الملف</a></div>';
        }
    }
    ?>
    <div class="form-row">
        <label for="item_pdf">رفع ملف PDF للإعلان</label>
        <?php echo $existing_link; ?>
        <input type="file" name="item_pdf" id="item_pdf" accept="application/pdf" />
        <p class="help">مسموح بملفات PDF فقط. سيتم حفظ الملف في مجلد الثيم: <code>/oc-content/themes/<?php echo osc_current_web_theme(); ?>/images/pdf/</code></p>
    </div>
    <?php
}

// Handle the upload before item is posted
function pdf_uploader_handle_upload($aItem) {
    // if no file sent, do nothing (return same array)
    if (!isset($_FILES['item_pdf']) || !is_uploaded_file($_FILES['item_pdf']['tmp_name'])) {
        return $aItem;
    }

    $file = $_FILES['item_pdf'];

    // basic validation
    $max_size = 5 * 1024 * 1024; // 5 MB (adjust if needed)
    $allowed_types = array('application/pdf');

    if ($file['error'] !== UPLOAD_ERR_OK) {
        // attach flash error so user sees message
        osc_add_flash_error(sprintf('فشل رفع الملف: خطأ عبارة عن %s', $file['error']));
        return $aItem;
    }

    if ($file['size'] > $max_size) {
        osc_add_flash_error('حجم الملف أكبر من الحد المسموح (5MB).');
        return $aItem;
    }

    // Check MIME type (not 100% reliable) and extension
    $finfo = null;
    if (function_exists('finfo_open')) {
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mime = finfo_file($finfo, $file['tmp_name']);
        finfo_close($finfo);
    } else {
        $mime = $file['type'];
    }

    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

    if ($mime !== 'application/pdf' && $ext !== 'pdf') {
        osc_add_flash_error('نوع الملف غير مدعوم — ارفع ملف PDF فقط.');
        return $aItem;
    }

    // prepare destination folder
    $dest_dir = osc_content_path() . 'themes/' . osc_current_web_theme() . '/images/pdf/';
    if (!is_dir($dest_dir)) {
        @mkdir($dest_dir, 0755, true);
    }

    // sanitize filename and avoid collisions
    $base = preg_replace('/[^a-z0-9_\-\.]/i', '_', pathinfo($file['name'], PATHINFO_FILENAME));
    $filename = $base . '_' . time() . '.' . $ext;
    $dest = $dest_dir . $filename;

    if (!move_uploaded_file($file['tmp_name'], $dest)) {
        osc_add_flash_error('فشل حفظ الملف على الخادم. تحقق من صلاحيات المجلد.');
        return $aItem;
    }

    // Build public URL to the file
    $relative = osc_content_url() . 'themes/' . osc_current_web_theme() . '/images/pdf/' . $filename;

    // Append a link to description so it's visible on the item page
    // (we keep any existing description)
    $link_html = "\n<p>ملف التحميل: <a href=\"$relative\" target=\"_blank\">تحميل/عرض ملف PDF</a></p>";

    if (isset($aItem['s_description']) && trim($aItem['s_description']) !== '') {
        $aItem['s_description'] .= $link_html;
    } else {
        $aItem['s_description'] = $link_html;
    }

    // Optionally: store filename in a SESSION so we can use it on edit or later
    if (!session_id()) @session_start();
    $_SESSION['pdf_uploader_last_file'] = $filename;

    return $aItem;
}

// Utility: show flash errors helper if not exists
if (!function_exists('osc_add_flash_error')) {
    function osc_add_flash_error($msg) {
        if (!session_id()) @session_start();
        if (!isset($_SESSION['flash_errors'])) $_SESSION['flash_errors'] = array();
        $_SESSION['flash_errors'][] = $msg;
    }
}

?>
